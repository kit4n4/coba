const autoClickButton = document.createElement("button");
autoClickButton.id = "autoClickButton";
autoClickButton.textContent = "Start Auto Click";
document.body.appendChild(autoClickButton);

let autoClickInterval = null;
let isActive = false;

function startAutoClick() {
  autoClickInterval = setInterval(() => {
    const target = document.querySelector('[alt*="Circle Image"][class*="object-cover brightness-0 invert"]');
    if (target) {
      target.click();
    }
  }, 5000);
}

function stopAutoClick() {
  clearInterval(autoClickInterval);
  autoClickInterval = null;
}

autoClickButton.addEventListener("click", () => {
  if (!isActive) {
    startAutoClick();
    isActive = true;
    autoClickButton.textContent = "Stop Auto Click";
  } else {
    stopAutoClick();
    isActive = false;
    autoClickButton.textContent = "Start Auto Click";
  }
});